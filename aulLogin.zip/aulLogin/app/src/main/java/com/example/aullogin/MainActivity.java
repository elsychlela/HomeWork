package com.example.aullogin;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    public EditText usernameET,passwordET;
    public Button loginBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        usernameET = (EditText)findViewById(R.id.usernameTxt);
        passwordET = (EditText)findViewById(R.id.PasswordTxt);
        loginBtn = (Button)findViewById(R.id.loginBtn);
        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username = usernameET.getText().toString();
                String password = passwordET.getText().toString();
                if(username.isEmpty() || password.isEmpty()) {
                    Toast.makeText(getApplicationContext(),"Please fill the missing Fields",Toast.LENGTH_LONG).show();
                }
                else {
                    if(username.equalsIgnoreCase("aul") && password.equalsIgnoreCase("aul")) {
//                        isValidLogin
                        Intent cypherIntent = new Intent(getApplicationContext(),cipherActivity.class);
                        cypherIntent.putExtra("isValidLogin",true);
                        getApplicationContext().startActivity(cypherIntent);
                        finish();
                    }
                    else {
                        Intent cypherIntent = new Intent(getApplicationContext(),cipherActivity.class);
                        cypherIntent.putExtra("isValidLogin",false);
                        getApplicationContext().startActivity(cypherIntent);
                        finish();
                    }
                }
            }
        });
    }
}
