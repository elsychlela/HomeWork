package com.example.aullogin;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class cipherActivity extends AppCompatActivity {

    public TextView failTxtVw,encipherTxtVw,countTxt;
    public EditText cypherText;
    public Button backBtn,cypherBtn,logoutBtn,shareBtn;
    public boolean isValidLogin;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cipher);
        isValidLogin = getIntent().getExtras().getBoolean("isValidLogin");
        failTxtVw = (TextView)findViewById(R.id.failTxtVw);
        encipherTxtVw = (TextView)findViewById(R.id.encipherTxt);
        countTxt = (TextView)findViewById(R.id.countTxt);
        cypherText = (EditText)findViewById(R.id.correctTxt);
        backBtn = (Button)findViewById(R.id.backBtn);
        cypherBtn = (Button)findViewById(R.id.encipherBtn);
        logoutBtn = (Button)findViewById(R.id.logoutBtn);
        shareBtn = (Button)findViewById(R.id.shareBtn);
        cypherText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                String textToBeCiphered = cypherText.getText().toString();
                int currenctCount =  textToBeCiphered.length();
                int remaingCaracters = 256 - currenctCount;
                countTxt.setText("you still have "+remaingCaracters+ " Caracters");
            }
        });
        shareBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent shareIntent = new Intent(Intent.ACTION_SEND);
                shareIntent.setType("text/plain");
                String textToBeShared = cypherText.getText().toString();
                shareIntent.putExtra(Intent.EXTRA_SUBJECT,"My App Subject");
                shareIntent.putExtra(Intent.EXTRA_TEXT,textToBeShared);
                getApplicationContext().startActivity(Intent.createChooser(shareIntent,"share via"));
            }
        });
        logoutBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent mainAct = new Intent(getApplicationContext(),MainActivity.class);
                getApplicationContext().startActivity(mainAct);
                finish();
            }
        });
        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent mainAct = new Intent(getApplicationContext(),MainActivity.class);
                getApplicationContext().startActivity(mainAct);
                finish();
            }
        });
        cypherBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String textToBeCiphered = cypherText.getText().toString();
                textToBeCiphered = textToBeCiphered.toUpperCase();
                encipherTxtVw.setText(textToBeCiphered);
            }
        });
        if(isValidLogin) {
            backBtn.setVisibility(View.GONE);
            failTxtVw.setVisibility(View.GONE);
        }
        else {
            encipherTxtVw.setVisibility(View.GONE);
            countTxt.setVisibility(View.GONE);
            cypherText.setVisibility(View.GONE);
            cypherBtn.setVisibility(View.GONE);
            shareBtn.setVisibility(View.GONE);
            logoutBtn.setVisibility(View.GONE);
        }
    }
}
